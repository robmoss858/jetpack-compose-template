package com.ferhatozcelik.jetpackcomposetemplate

import java.io.Closeable

/**
 * Raw byte channel abstraction for ELM327 adapters.
 * Allows Bluetooth SPP and USB-Serial transports to share the exact same Elm327Session.
 */
interface ElmByteChannel : Closeable {
    fun available(): Int
    fun read(buffer: ByteArray, offset: Int = 0, length: Int = buffer.size): Int
    fun write(data: ByteArray)
}
